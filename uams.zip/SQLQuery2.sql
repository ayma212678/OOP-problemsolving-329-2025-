CREATE DATABASE UMS;
GO
USE UMS;
GO

CREATE TABLE DegreeProgram (
    Name VARCHAR(50) PRIMARY KEY,
    Seats INT,
    MinMarks INT
);

CREATE TABLE Subject (
    Code VARCHAR(50) PRIMARY KEY,
    Type VARCHAR(50),
    CreditHours INT,
    SubjectFees INT,
    DegreeName VARCHAR(50) FOREIGN KEY REFERENCES DegreeProgram(Name)
);

CREATE TABLE Student (
    Name VARCHAR(50) PRIMARY KEY,
    Marks INT,
    AdmittedDegree VARCHAR(50) FOREIGN KEY REFERENCES DegreeProgram(Name) NULL
);